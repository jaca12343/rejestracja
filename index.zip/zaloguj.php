<?php
$email = "essa";
while(true){
    echo "essa";
}
echo json_encode($email);
?>